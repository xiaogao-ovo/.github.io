多主题优雅个人主页
后续计划增加主页时钟,主页音乐播放器
增加php管理后台

# 1.3最新更新
优化加载动画
增加点击q弹动画
增加5套亮色主题,且通用css变量实现,完全取消主题切换对js的依赖.新增主题只需要在/static/root.css修改
去除前台切换多主题,只可切换暗夜模式
增加模糊,有背景整体模糊和卡片模糊
卡片半透明模糊或者背景模糊二选一
增加自定义功能
优化细节
优化动效,去除无用效果
电脑端改为一行4个
手机端有一行两个和一行一个
# 1.2
新增侧边栏并且支持移动端弹出
去除白色主题
优化动效,优化卡顿
# 1.0
无侧边栏白天黑夜切换
三套主题
前台一键切换
# 最新版图片效果

![1.png][1]
![2.png][2]
![3.png][3]
![4.png][4]
![5.png][5]
![6.png][6]
![7.png][7]
# 使用

下载解压即可访问
/static/root.css主题文件
/static/style.css样式文件
在此可以修改各种字体
/static/img/favicon.ico网页ico和主页头像
/static/script.js js文件

# 关于

我的个人主页是zyyo.net
我的开源博客xtbbb.com

# 缘由

受到xhofe和ddiu个人主页的灵感启发

感谢这二位大佬

决定写款主页练手

初个版本花了几个小时,页面并不复杂,但是在后续我花费了很多时间去优化这个主页,因为我有非常严重的强迫证,非常抓细节

我真的为了这个主页的优化后续付出了非常多的心力,请还不要攻击,喜欢可以赞助,不喜欢可以走开

# 特色

具有白天和黑夜模式

白天模式有5套精美主题

模糊方式有背景整体模糊和卡片模糊,可以通过css切换主题

加了数百个精美动画-页面效果,但是又杜绝花里胡哨,一切只为优雅

原生html,css,js，未使用任何框架和插件,问就是不会

# 下载

github:https://github.com/ZYYO666/homepage

添加QQ裙下载:560938976

演示站:https://zyyo.net

#技术栈

html
css
js

# 鸣谢

iconfont图标
Pacifico-Regular字体
Ubuntu-Regular字体

# 备注

页面图标都是svg,可也自己找然后切换

字体目前最新版是鸿蒙字体,可以自己设置



  
  [1]: https://zyyo.net/img/1.jpg
  [2]: https://zyyo.net/img/2.jpg
  [3]: https://zyyo.net/img/3.jpg
  [4]: https://zyyo.net/img/4.jpg
  [5]: https://zyyo.net/img/5.jpg
  [6]: https://zyyo.net/img/6.jpg
  [7]: https://zyyo.net/img/7.jpg
